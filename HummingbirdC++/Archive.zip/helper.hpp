//
//  helper.hpp
//  HummingbirdC++
//
//  Created by David Chen on 4/17/17.
//  Copyright © 2017 David Chen. All rights reserved.
//

#ifndef helper_hpp
#define helper_hpp

#include <stdio.h>

#endif /* helper_hpp */
